# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import hotel_restaurant
from . import hotel_folio
from . import hotel_menucard
