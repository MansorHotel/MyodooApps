This Module provides state-wise view for hotel reservation for better business intelligence.

.. image:: https://raw.githubusercontent.com/OCA/vertical-hotel/10.0/report_hotel_reservation/static/description/sbres.png
   :width: 750px
