# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import account_move
from . import hotel_folio
from . import hotel_room
from . import hotel_services
from . import product_product
from . import res_company
