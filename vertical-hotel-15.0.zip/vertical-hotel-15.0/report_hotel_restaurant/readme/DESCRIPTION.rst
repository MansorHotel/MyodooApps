This Module provides state-wise view for hotel restaurant for better business intelligence.
