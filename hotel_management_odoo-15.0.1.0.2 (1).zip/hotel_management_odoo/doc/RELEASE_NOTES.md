## Module <hotel management>

#### 11.5.2022
#### Version 15.0.1.0.0
##### ADD
- Initial Commit for hotel_management_odoo

#### 2.8.2022
#### Version 15.0.1.0.1
#### UPDT
- room reservation-number of persons validation issue

#### 31.10.2022
#### Version 15.0.1.0.2
#### UPDT
- multiple room checkin & checkout
